<div id="footer">
	<div class="container">
		<div class="col-xs-11">
			<div class="footer-text">
				&copy <?php echo date("Y")." ".$ProjectName." ".$ProjectVersion;?> for JobStreet.com
			</div>
		</div>
		<div class="col-xs-1">
			<div class="footer-text text-center">
				<i data-placement="top" title="Scroll Up" class="icon-arrow-up-circle" id="gotop"></i>
			</div>
		</div>
	</div>
</div>

<script src="js/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/site-demo.js"></script>