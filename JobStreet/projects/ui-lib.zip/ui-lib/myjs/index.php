<?php
$default="templates.php";
header("location:".$default);
?>