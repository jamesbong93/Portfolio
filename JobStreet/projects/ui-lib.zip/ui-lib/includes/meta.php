<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Cache-Control" content="Public">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">

<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="Author" content="Leo Hee Fook Yew">
<link rel="stylesheet" href="<?php echo $ProjectCDN;?>">
<link rel="stylesheet" href="<?php echo $IconFontCDN;?>">
<link rel="stylesheet" href="<?php echo $HostURL ?>css/style.css">
<!-- Favicon -->
<link rel="shortcut icon" href="ico/favicon.png">
<link rel="apple-touch-icon" href="ico/touch-icon-iphone.png">
<link rel="apple-touch-icon" sizes="76x76" href="ico/touch-icon-ipad.png">
<link rel="apple-touch-icon" sizes="120x120" href="ico/touch-icon-iphone-retina.png">
<link rel="apple-touch-icon" sizes="152x152" href="ico/touch-icon-ipad-retina.png">
<link rel="apple-touch-icon" sizes="180x180" href="ico/touch-icon-iphone6p-ios8.png">
<!-- End of Favicon -->