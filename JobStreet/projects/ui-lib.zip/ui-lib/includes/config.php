<?php
date_default_timezone_set("Asia/Kuala_Lumpur");
$ProjectName="Project Pi";
$ProjectVersion="1.3.21";
$ProjectLastUpdate="4 Sept 2015";
$ProjectURL="http://ui.jobstreet.com";
$ProjectCDNHost="http://dna.jsstatic.com";
$ProjectCDN=$ProjectCDNHost."/pi/pi-".$ProjectVersion.".css";
$HostURL="http://ui.jobstreet.com/";

$SIVAVersion="1.2.17";
//$SIVADateRelease="1 April 2015";
$MYJSVersion="1.2.12";
//$MYJSDateRelease="30 March 2015";

$IconFontVersion="2.1";
$IconFontCDN=$ProjectCDNHost."/pi/icon-font/".$IconFontVersion."/icon-font.css";
?>