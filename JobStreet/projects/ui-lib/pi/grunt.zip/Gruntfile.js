module.exports = function(grunt){
	// Load task
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	// Set task
	grunt.registerTask('default',['cssmin:combine']);
	grunt.initConfig({
		/*Source*/
		source:{
			file:['./lib']
		},
		/*Output*/
		output:{
			file:['../css']
		},
		/*Read package.json data and pkg able to access variable package.json here*/
		pkg:grunt.file.readJSON('package.json'),
		/*Combine & Minify*/
		cssmin:{
			combine:{
				files:{
					'<%=output.file%>/pi.css':['<%=source.file%>/*.css']
				}
			}
		}
	});
};