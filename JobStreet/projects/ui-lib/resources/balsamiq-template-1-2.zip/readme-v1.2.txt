Balsamiq Template Library V1.2 for Project Pi
=============================================
- Download and unzip Balsamiq Templates: ProjectPi_Layout.bmml & ProjectPi_UI.bmml
- Open Balsamiq template, copy elements into your project
- Make use of png images inside folder "assets" for better visual

Version Log
===========
V1.1 (31 March 2014)
  - Create most use webpage elements into Balsamiq template, based on current UI design in Project Pi
  - Convert existing icons to png images

V1.2 (17 April 2014)
  - Update buttons design sync with Project Pi v1.0.6
  - Simplify elements
  - Additional 2 icons: opened door and closed door